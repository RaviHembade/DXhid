# Readme for DXHIDLIB - Dataexchange service for HID and BMS Interfacing.

# Prerequisite
1. Python 2
2. Package tb-mqtt-client==1.0.0

